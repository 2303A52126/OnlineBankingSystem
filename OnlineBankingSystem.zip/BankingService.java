import java.sql.*;
import java.util.Scanner;

public class BankingService {

    public void registerUser(Scanner sc) {
        try (Connection con = DBConnection.getConnection()) {
            System.out.print("Enter name: ");
            String name = sc.next();
            System.out.print("Enter password: ");
            String pass = sc.next();

            String query = "INSERT INTO users(name, password) VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, pass);
            ps.executeUpdate();

            System.out.println("User Registered Successfully!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int login(Scanner sc) {
        try (Connection con = DBConnection.getConnection()) {
            System.out.print("Enter name: ");
            String name = sc.next();
            System.out.print("Enter password: ");
            String pass = sc.next();

            String query = "SELECT * FROM users WHERE name=? AND password=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, pass);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("Login Successful!");
                return rs.getInt("id");
            } else {
                System.out.println("Invalid credentials!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    public void createAccount(int userId) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "INSERT INTO accounts(user_id, balance) VALUES (?, 0)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, userId);
            ps.executeUpdate();

            System.out.println("Account Created!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deposit(int accId, double amount) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "UPDATE accounts SET balance = balance + ? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setDouble(1, amount);
            ps.setInt(2, accId);
            ps.executeUpdate();

            System.out.println("Deposit Successful!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void withdraw(int accId, double amount) {
        try (Connection con = DBConnection.getConnection()) {
            String check = "SELECT balance FROM accounts WHERE id=?";
            PreparedStatement ps1 = con.prepareStatement(check);
            ps1.setInt(1, accId);
            ResultSet rs = ps1.executeQuery();

            if (rs.next() && rs.getDouble("balance") >= amount) {
                String query = "UPDATE accounts SET balance = balance - ? WHERE id=?";
                PreparedStatement ps2 = con.prepareStatement(query);
                ps2.setDouble(1, amount);
                ps2.setInt(2, accId);
                ps2.executeUpdate();

                System.out.println("Withdraw Successful!");
            } else {
                System.out.println("Insufficient Balance!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void checkBalance(int accId) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT balance FROM accounts WHERE id=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, accId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Balance: " + rs.getDouble("balance"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}