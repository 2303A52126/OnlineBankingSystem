import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BankingService service = new BankingService();

        while (true) {
            System.out.println("\n1. Register\n2. Login\n3. Exit");
            int choice = sc.nextInt();

            if (choice == 1) {
                service.registerUser(sc);
            } else if (choice == 2) {
                int userId = service.login(sc);
                if (userId != -1) {
                    service.createAccount(userId);

                    System.out.print("Enter Account ID: ");
                    int accId = sc.nextInt();

                    while (true) {
                        System.out.println("\n1. Deposit\n2. Withdraw\n3. Check Balance\n4. Logout");
                        int op = sc.nextInt();

                        if (op == 1) {
                            System.out.print("Amount: ");
                            service.deposit(accId, sc.nextDouble());
                        } else if (op == 2) {
                            System.out.print("Amount: ");
                            service.withdraw(accId, sc.nextDouble());
                        } else if (op == 3) {
                            service.checkBalance(accId);
                        } else break;
                    }
                }
            } else break;
        }
    }
}